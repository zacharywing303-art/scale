import { Router } from "express";
import * as employeeController from "../controllers/employee.controller";

const router = Router();

router.get("/", employeeController.getEmployees);
router.get("/:id", employeeController.getEmployee);
router.post("/", employeeController.createEmployee); // protected
router.patch("/:id", employeeController.updateEmployee);
router.delete("/:id", employeeController.deleteEmployee);

export default router;
